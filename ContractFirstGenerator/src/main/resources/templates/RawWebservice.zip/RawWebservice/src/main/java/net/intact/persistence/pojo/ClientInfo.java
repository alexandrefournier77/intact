package net.intact.persistence.pojo;

public class ClientInfo {

    private String clientNumber;
    private String firstName;
    private String lastName;

    public ClientInfo(String clientNumber, String firstName, String lastName) {
        this.clientNumber = clientNumber;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    public String getClientNumber() {
        return clientNumber;
    }

    public void setClientNumber(String clientNumber) {
        this.clientNumber = clientNumber;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

}
