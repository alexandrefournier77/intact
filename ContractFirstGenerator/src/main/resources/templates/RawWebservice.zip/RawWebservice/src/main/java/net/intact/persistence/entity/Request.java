package net.intact.persistence.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "REQUEST")
public class Request {

    @Id
    @Column(name = "REQUEST_ID")
    private Integer requestId;

    @Column(name = "REQUEST_TYPE_CD")
    private String requestTypeCode;

    @Column(name = "LAST_NAME_TXT")
    private String lastName;

    @Column(name = "FIRST_NAME_TXT")
    private String firstName;

    @Column(name = "SUFFIX_NAME_TXT")
    private String suffixName;

    @Column(name = "ADDRESS_LINE1_TXT")
    private String addressLine;

    @Column(name = "MUNICIPALITY_TXT")
    private String municipality;

    @Column(name = "PROVINCE_CD")
    private String provinceCode;

    @Column(name = "POSTAL_CD")
    private String postalCode;

    @Column(name = "VEHICLE_IDENTIFICATION_NBR")
    private String vehicleIdentificationNumber;

    @Column(name = "EMAIL_ADDRESS_TXT")
    private String emailAddress;

    @Column(name = "VEHICLE_YR")
    private String vehicleYear;

    @Column(name = "VEHICLE_MAKE_TXT")
    private String vehicleMake;

    @Column(name = "VEHICLE_MODEL_TXT")
    private String vehicleModel;

    @Column(name = "LANGUAGE_OF_COMMUNICATION_CD")
    private String languageCommunicationCode;

    @Column(name = "BROKER_NBR")
    private String brokerNumber;

    @Column(name = "RESULT_CD")
    private String resultCode;

    @Column(name = "RESULT_DESC")
    private String resultDescription;

    @Column(name = "CLIENT_REQUESTED_DT")
    private String clientRequestedDate;

    @Column(name = "UBI_AREA_CODE_NBR")
    private String ubiAreaCodeNumber;

    @Column(name = "UBI_PHONE_NBR")
    private String ubiPhoneNumber;

    @Column(name = "UBI_CLIENT_ID")
    private String ubiClientId;

    @Column(name = "SYSTEM_CREATE_TS")
    private String systemCreate;

    @Column(name = "SYSTEM_LAST_UPDATE_TS")
    private String systemLastUpdate;

    public Integer getRequestId() {
        return requestId;
    }

    public void setRequestId(Integer requestId) {
        this.requestId = requestId;
    }

    public String getRequestTypeCode() {
        return requestTypeCode;
    }

    public void setRequestTypeCode(String requestTypeCode) {
        this.requestTypeCode = requestTypeCode;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getSuffixName() {
        return suffixName;
    }

    public void setSuffixName(String suffixName) {
        this.suffixName = suffixName;
    }

    public String getAddressLine() {
        return addressLine;
    }

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }

    public String getMunicipality() {
        return municipality;
    }

    public void setMunicipality(String municipality) {
        this.municipality = municipality;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getVehicleIdentificationNumber() {
        return vehicleIdentificationNumber;
    }

    public void setVehicleIdentificationNumber(String vehicleIdentificationNumber) {
        this.vehicleIdentificationNumber = vehicleIdentificationNumber;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getVehicleYear() {
        return vehicleYear;
    }

    public void setVehicleYear(String vehicleYear) {
        this.vehicleYear = vehicleYear;
    }

    public String getVehicleMake() {
        return vehicleMake;
    }

    public void setVehicleMake(String vehicleMake) {
        this.vehicleMake = vehicleMake;
    }

    public String getVehicleModel() {
        return vehicleModel;
    }

    public void setVehicleModel(String vehicleModel) {
        this.vehicleModel = vehicleModel;
    }

    public String getLanguageCommunicationCode() {
        return languageCommunicationCode;
    }

    public void setLanguageCommunicationCode(String languageCommunicationCode) {
        this.languageCommunicationCode = languageCommunicationCode;
    }

    public String getBrokerNumber() {
        return brokerNumber;
    }

    public void setBrokerNumber(String brokerNumber) {
        this.brokerNumber = brokerNumber;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultDescription() {
        return resultDescription;
    }

    public void setResultDescription(String resultDescription) {
        this.resultDescription = resultDescription;
    }

    public String getClientRequestedDate() {
        return clientRequestedDate;
    }

    public void setClientRequestedDate(String clientRequestedDate) {
        this.clientRequestedDate = clientRequestedDate;
    }

    public String getUbiAreaCodeNumber() {
        return ubiAreaCodeNumber;
    }

    public void setUbiAreaCodeNumber(String ubiAreaCodeNumber) {
        this.ubiAreaCodeNumber = ubiAreaCodeNumber;
    }

    public String getUbiPhoneNumber() {
        return ubiPhoneNumber;
    }

    public void setUbiPhoneNumber(String ubiPhoneNumber) {
        this.ubiPhoneNumber = ubiPhoneNumber;
    }

    public String getUbiClientId() {
        return ubiClientId;
    }

    public void setUbiClientId(String ubiClientId) {
        this.ubiClientId = ubiClientId;
    }

    public String getSystemCreate() {
        return systemCreate;
    }

    public void setSystemCreate(String systemCreate) {
        this.systemCreate = systemCreate;
    }

    public String getSystemLastUpdate() {
        return systemLastUpdate;
    }

    public void setSystemLastUpdate(String systemLastUpdate) {
        this.systemLastUpdate = systemLastUpdate;
    }

}
