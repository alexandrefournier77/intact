package net.intact.persistence.entity;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "UBI_CLIENT")
public class UbiClient {

    @Id
    @Column(name = "UBI_CLIENT_ID")
    private Integer ubiClientId;

    @Column(name = "UBI_CLIENT_NBR")
    private String ubiClientNbr;

    @Column(name = "PROVIDER_UBI_CLIENT_NBR")
    private String providerUbiClientNbr;

    @Column(name = "PROGRAM_CD")
    private String programCd;

    @Column(name = "CONTRACT_CD")
    private String contractCd;

    @Column(name = "COMPANY_IND")
    private String companyInd;

    @Column(name = "PROVIDER_EFFECTIVE_DT")
    private Date providerEffectiveDt;

    @Column(name = "PROVIDER_EXPIRY_DT")
    private Date providerExpiryDt;

    @Column(name = "SERVICE_PROVIDER_ID")
    private Integer serviceProviderID;

    @Column(name = "SYSTEM_CREATE_TS")
    private String systemCreateTs;

    @Column(name = "SYSTEM_LAST_UPDATE_TS")
    private String systemLastUpdateTs;

    @Column(name = "EVAL_PERIOD_IN_DAYS_QTY")
    private Integer evalPeriodInDaysQty;

    @Column(name = "EFFECTIVE_DT")
    private Date effectiveDt;

    @Column(name = "EXPIRY_DT")
    private Date expiryDt;

    @Column(name = "EVAL_PERIOD_EFFECTIVE_DT")
    private Date evalPeriodEffectiveDt;

    @Column(name = "UBI_ALGORITHM_CODE")
    private String ubiAlgorithmCd;

    @Column(name = "INIT_EVAL_PERIOD_IN_DAYS_QTY")
    private Integer initEvalPeriodInDaysQty;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "ubiClientId", cascade = CascadeType.ALL)
    private List<Request> requests;

    public int getUbiClientId() {
        return ubiClientId;
    }

    public void setUbiClientId(int ubi_client_id) {
        this.ubiClientId = ubi_client_id;
    }

    public String getUbiClientNbr() {
        return ubiClientNbr;
    }

    public void setUbiClientNbr(String ubiClientNbr) {
        this.ubiClientNbr = ubiClientNbr;
    }

    public String getProviderUbiClientNbr() {
        return providerUbiClientNbr;
    }

    public void setProviderUbiClientNbr(String providerUbiClientNbr) {
        this.providerUbiClientNbr = providerUbiClientNbr;
    }

    public String getProgramCd() {
        return programCd;
    }

    public void setProgramCd(String programCd) {
        this.programCd = programCd;
    }

    public String getContractCd() {
        return contractCd;
    }

    public void setContractCd(String contractCd) {
        this.contractCd = contractCd;
    }

    public String getCompanyInd() {
        return companyInd;
    }

    public void setCompanyInd(String companyInd) {
        this.companyInd = companyInd;
    }

    public Date getProviderEffectiveDt() {
        return providerEffectiveDt;
    }

    public void setProviderEffectiveDt(Date providerEffectiveDt) {
        this.providerEffectiveDt = providerEffectiveDt;
    }

    public Date getProviderExpiryDt() {
        return providerExpiryDt;
    }

    public void setProviderExpiryDt(Date providerExpiryDt) {
        this.providerExpiryDt = providerExpiryDt;
    }

    public Date getEffectiveDt() {
        return effectiveDt;
    }

    public void setEffectiveDt(Date effectiveDt) {
        this.effectiveDt = effectiveDt;
    }

    public Date getExpiryDt() {
        return expiryDt;
    }

    public void setExpiryDt(Date expiryDt) {
        this.expiryDt = expiryDt;
    }

    public Integer getServiceProviderID() {
        return serviceProviderID;
    }

    public void setServiceProviderID(Integer serviceProviderID) {
        this.serviceProviderID = serviceProviderID;
    }

    public String getSystemCreateTs() {
        return systemCreateTs;
    }

    public void setSystemCreateTs(String systemCreateTs) {
        this.systemCreateTs = systemCreateTs;
    }

    public String getSystemLastUpdateTs() {
        return systemLastUpdateTs;
    }

    public void setSystemLastUpdateTs(String systemLastUpdateTs) {
        this.systemLastUpdateTs = systemLastUpdateTs;
    }

    public Integer getInitEvalPeriodInDaysQty() {
        return initEvalPeriodInDaysQty;
    }

    public void setInitEvalPeriodInDaysQty(Integer initEvalPeriodInDaysQty) {
        this.initEvalPeriodInDaysQty = initEvalPeriodInDaysQty;
    }

    public Integer getEvalPeriodInDaysQty() {
        return evalPeriodInDaysQty;
    }

    public void setEvalPeriodInDaysQty(Integer evalPeriodInDaysQty) {
        this.evalPeriodInDaysQty = evalPeriodInDaysQty;
    }

    public Date getEvalPeriodEffectiveDt() {
        return evalPeriodEffectiveDt;
    }

    public void setEvalPeriodEffectiveDt(Date evalPeriodEffectiveDt) {
        this.evalPeriodEffectiveDt = evalPeriodEffectiveDt;
    }

    public String getUbiAlgorithmCd() {
        return ubiAlgorithmCd;
    }

    public void setUbiAlgorithmCd(String ubiAlgorithmCd) {
        this.ubiAlgorithmCd = ubiAlgorithmCd;
    }

    public List<Request> getRequestList() {
        return requests;
    }

    public void setRequestList(List<Request> requests) {
        this.requests = requests;
    }
}
