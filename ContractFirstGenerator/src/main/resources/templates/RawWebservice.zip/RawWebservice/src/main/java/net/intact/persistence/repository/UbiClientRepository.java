package net.intact.persistence.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import net.intact.persistence.entity.UbiClient;
import net.intact.persistence.pojo.ClientInfo;

public interface UbiClientRepository extends CrudRepository<UbiClient, Integer> {

    @Query("SELECT new net.intact.persistence.pojo.ClientInfo(uc.ubiClientNbr, re.firstName, re.lastName) "
            + "FROM UbiClient uc "
            + "INNER JOIN uc.requests re "
            + "GROUP BY uc.ubiClientNbr, re.firstName, re.lastName")
    public List<ClientInfo> getAllClientsWithName();

}
